/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tech.blog.entities;

import java.sql.*;

/**
 *
 * @author jaitr
 */
public class user {

    private int ID;
    private String Name;
    private String email;
    private String password;
    private String gender;
    private Timestamp dateTime;

    public user(int ID, String Name, String email, String password, String gender, Timestamp dateTime) {
        this.ID = ID;
        this.Name = Name;
        this.email = email;
        this.password = password;
        this.gender = gender;
        this.dateTime = dateTime;
    }

    public user() {
        
    }

    public user(String Name, String email, String password, String gender ) {
        this.Name = Name;
        this.email = email;
        this.password = password;
        this.gender = gender;
       
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public Timestamp getDateTime() {
        return dateTime;
    }

    public void setDateTime(Timestamp dateTime) {
        this.dateTime = dateTime;
    }
    

}
