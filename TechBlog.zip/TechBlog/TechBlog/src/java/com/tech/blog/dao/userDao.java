/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tech.blog.dao;

/**
 *
 * @author jaitr
 */
import com.tech.blog.entities.user;
import java.sql.*;
public class userDao {
    private Connection con;

    public userDao(Connection con) 
    {
        this.con = con;
    }
    public boolean insertUser(user us)
    {
        boolean f=false;
        try
        {
            String que="insert into users(Name,email,password,gender) values (?,?,?,?)";
            PreparedStatement pstmst=this.con.prepareStatement(que);
            pstmst.setString(1,us.getName());
            pstmst.setString(2,us.getEmail());
            pstmst.setString(3,us.getPassword());
            pstmst.setString(4,us.getGender());
            pstmst.executeUpdate();
            f=true;
        }
        catch(Exception e)
                {
                    e.printStackTrace();
                }
        return f;
    }
    public user getuserbyemailandpassword(String email,String password)
    {
        user uus=null;
        try
        {
            String query="select * from users where email=? and password=?";
            PreparedStatement pstmst=con.prepareStatement(query);
            pstmst.setString(1, email);
            pstmst.setString(2, password);
            ResultSet set=pstmst.executeQuery();
            if(set.next())
            {
                uus=new user();
                String name=set.getString("Name");
                uus.setName(name);
                uus.setID(set.getInt("ID"));
                uus.setEmail(set.getString("email"));
                uus.setPassword(set.getString("password"));
                uus.setGender(set.getString("gender"));
                uus.setDateTime(set.getTimestamp("Regdate"));
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        
        
        return uus;
    }
    
}
